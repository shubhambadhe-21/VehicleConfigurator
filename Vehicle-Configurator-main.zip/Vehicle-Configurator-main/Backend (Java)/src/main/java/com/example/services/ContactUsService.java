package com.example.services;

import com.example.entities.ContactUs;

public interface ContactUsService {
    public void saveContact(ContactUs feedback);
}
