package com.example.services;

import com.example.entities.FeedbackEntity;

public interface FeedbackService {
    public void saveFeedback(FeedbackEntity feedback);
}
