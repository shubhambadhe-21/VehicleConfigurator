package com.example.repositories;

public class ComponentRepository {

}