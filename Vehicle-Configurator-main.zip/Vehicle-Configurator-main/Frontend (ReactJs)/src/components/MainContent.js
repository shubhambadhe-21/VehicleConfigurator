import React from "react";

function MainContent() {
  return (
    <div className="main-content">
      <h1>Welcome to the Vehicle Configurator App</h1>
      {/* Add more content specific to your application */}
    </div>
  );
}

export default MainContent;
